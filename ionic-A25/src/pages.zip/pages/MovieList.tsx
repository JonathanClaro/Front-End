import { IonModal, IonInput, IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonSearchbar, IonItem, IonLabel, IonButton, IonButtons, IonGrid, IonRow, IonCol, IonCard, IonCardContent, IonImg, IonBadge } from '@ionic/react';
import { useState } from 'react';
import './MovieList.css';

const MovieList: React.FC = () => {
  const [searchText, setSearchText] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedMovie, setSelectedMovie] = useState<any>(null);

const allMovies = [
  {
    id: 1,
    title: 'Dune: Part Two',
    img: 'https://media.themoviedb.org/t/p/w300_and_h450_bestv2/8LJJjLjAzAwXS40S5mx79PJ2jSs.jpg',
    description: 'Paul Atreides une-se aos Fremen numa jornada de vingança e destino em Arrakis.',
    genre: 'Sci-Fi'
  },
  {
    id: 2,
    title: 'Oppenheimer',
    img: 'https://media.themoviedb.org/t/p/w300_and_h450_bestv2/1OsQJEoSXBjduuCvDOlRhoEUaHu.jpg',
    description: 'A história de J. Robert Oppenheimer e o Projeto Manhattan.',
    genre: 'Biografia/Drama'
  },
  {
    id: 3,
    title: 'Top Gun: Maverick',
    img: 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2/8v3lrllHYRrqEdYWLyscH4RGFDO.jpg',
    description: 'Maverick regressa para treinar uma nova geração de pilotos.',
    genre: 'Ação'
  },
  {
    id: 4,
    title: 'Babylon',
    img: 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2/qZUmMxJbGmkIYwnS7qRfSOREmvC.jpg',
    description: 'Excessos e ambição em Hollywood na transição do cinema mudo para o sonoro.',
    genre: 'Drama'
  },
  {
    id: 5,
    title: 'Once Upon a Time in Hollywood',
    img: 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2/zgr02U2Fh0sR5JtaAXY5yBU1wka.jpg',
    description: 'Um ator em declínio e o seu duplo atravessam a Hollywood de 1969.',
    genre: 'Comédia/Drama'
  },
  {
    id: 6,
    title: 'Avengers: Endgame',
    img: 'https://image.tmdb.org/t/p/w500/ulzhLuWrPK07P1YkdWQLZnQh1JL.jpg',
    description: 'Os Vingadores tentam desfazer o estalar de dedos de Thanos numa derradeira missão.',
    genre: 'Ação/Sci-Fi'
  },
  {
    id: 7,
    title: 'Avengers: Infinity War',
    img: 'https://image.tmdb.org/t/p/w500/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg',
    description: 'Thanos recolhe as Joias do Infinito enquanto heróis de todo o mundo se unem.',
    genre: 'Ação/Sci-Fi'
  },
  {
    id: 8,
    title: 'Blade Runner 2049',
    img: 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2/49pANIZXRAdHUiWjjBv4vxPeqRC.jpg',
    description: 'Um novo blade runner descobre um segredo que pode abalar a sociedade.',
    genre: 'Sci-Fi/Neo-noir'
  },
  {
    id: 9,
    title: 'La La Land',
    img: 'https://image.tmdb.org/t/p/w500/uDO8zWDhfWwoFdKS4fzkUJt0Rf0.jpg',
    description: 'Amor e ambições artísticas cruzam-se em Los Angeles.',
    genre: 'Musical/Romance'
  },
  {
    id: 10,
    title: 'Interstellar',
    img: 'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg',
    description: 'Uma expedição espacial procura um novo lar para a humanidade.',
    genre: 'Sci-Fi/Aventura'
  },
  {
    id: 11,
    title: 'Inception',
    img: 'https://image.tmdb.org/t/p/w500/edv5CZvWj09upOsy2Y6IwDhK8bt.jpg',
    description: 'Um ladrão invade sonhos para plantar uma ideia na mente de alguém.',
    genre: 'Sci-Fi/Thriller'
  },
  {
    id: 12,
    title: 'Toy Story 3',
    img: 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2/rf67AeS9nP8DD7dZYbvhjEVoIBf.jpg',
    description: 'Woody e Buzz enfrentam uma nova aventura quando Andy parte para a faculdade.',
    genre: 'Animação'
  },
  {
    id: 13,
    title: 'The Dark Knight',
    img: 'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg',
    description: 'Batman enfrenta o Joker numa batalha pelo futuro de Gotham.',
    genre: 'Ação/Crime'
  },
  {
    id: 14,
    title: 'Superbad',
    img: 'https://www.themoviedb.org/t/p/w600_and_h900_bestv2/vKFyD2wRl3qCKpbVWjIB3QAWo0K.jpg',
    description: 'Dois amigos tentam aproveitar ao máximo a última semana do secundário.',
    genre: 'Comédia'
  },
  {
    id: 15,
    title: 'Parasite',
    img: 'https://image.tmdb.org/t/p/w500/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg',
    description: 'Duas famílias coreanas entrelaçam-se num jogo social perigoso.',
    genre: 'Thriller/Drama'
  },
  {
  id: 16,
  title: 'Dune',
  img: 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/d5NXSklXo0qyIYkgV94XAgMIckC.jpg',
  description: 'O jovem Paul Atreides embarca numa jornada épica para salvar o seu povo e o futuro do planeta Arrakis.',
  genre: 'Sci-Fi/Aventura'
 },
 {
  id: 17,
  title: 'Inglourious Basterds',
  img: 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/7sfbEnaARXDDhKm0CZ7D7uc2sbo.jpg',
  description: 'Durante a Segunda Guerra Mundial, um grupo de soldados judeus americanos planeia eliminar líderes nazis na França ocupada.',
  genre: 'Ação/Drama'
 },
 {
  id: 18,
  title: 'Pulp Fiction',
  img: 'https://image.tmdb.org/t/p/w600_and_h900_bestv2/fIE3lAGcZDV1G6XM5KmuWnNsPp1.jpg',
  description: 'Histórias entrelaçadas de crime, redenção e ironia em Los Angeles.',
  genre: 'Crime/Drama'
}
];

  const filteredMovies = allMovies.filter(movie =>
    movie.title.toLowerCase().includes(searchText.toLowerCase()) ||
    movie.description.toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle className='page-title' slot="start">Movie List</IonTitle>
          <IonButtons slot="end">
            <IonButton onClick={() => window.location.href = '/home'}>Home</IonButton>
            <IonButton onClick={() => window.location.href = '/releases'}>Releases</IonButton>
            <IonButton onClick={() => window.location.href = '/movie-list'}>Movie List</IonButton>
            <IonButton onClick={() => setIsModalOpen(true)}>Subscribe</IonButton>
          </IonButtons>
        </IonToolbar>

        {/* newsletter */}
        <IonModal className="news-modal" isOpen={isModalOpen} onDidDismiss={() => setIsModalOpen(false)}>
          <IonHeader>
            <IonToolbar>
              <IonTitle>Subscribe to Newsletter</IonTitle>
            </IonToolbar>
          </IonHeader>
          <IonContent className="ion-padding">
            <IonItem>
              <IonLabel position="stacked">Email</IonLabel>
              <IonInput
                type="email"
                value={email}
                onIonChange={(e) => setEmail(e.detail.value!)}
                placeholder="Enter your email"
              />
            </IonItem>
            <IonButton expand="block" onClick={() => {
                setEmail('');
                setIsModalOpen(false);
              }} className="ion-margin-top">
                Subscribe
            </IonButton>
          </IonContent>
        </IonModal>

      </IonHeader>
      <IonContent fullscreen>
        <IonSearchbar
          value={searchText}
          onIonInput={(e) => setSearchText(e.detail.value!)}
          placeholder="Search movies..."
        />
        <IonGrid>
          <IonRow>
            {filteredMovies.map((movie) => (
              <IonCol size="3" size-md="2" key={movie.id}>
                <IonCard className='mv-card' onClick={() => {
                  setSelectedMovie(movie);
                  setShowDetailModal(true);
                }}>
                  <IonImg className='movie-card-img' src={movie.img} alt={movie.title} />
                </IonCard>
              </IonCol>
            ))}
          </IonRow>
        </IonGrid>

        <IonModal isOpen={showDetailModal} onDidDismiss={() => setShowDetailModal(false)} className="modal-details">
          <IonHeader>
            <IonToolbar>
              <IonTitle>{selectedMovie?.title}</IonTitle>
            </IonToolbar>
          </IonHeader>
          <IonContent>
            <IonCard>
              <IonCardContent>
                <IonRow>
                  <IonCol size='12' sizeMd='4'>
                    <IonImg className='movie-modal-img' src={selectedMovie?.img} alt={selectedMovie?.title} />
                  </IonCol>
                  <IonCol>
                <p>{selectedMovie?.description}</p>
                <p><strong>Director:</strong> John Doe</p>
                <p><strong>Cast:</strong> Actor 1, Actor 2, Actor 3</p>
                <IonBadge color="primary">{selectedMovie?.genre}</IonBadge>
                <p><strong>Release Year:</strong> 2023</p>
                </IonCol>
                </IonRow>
              </IonCardContent>
            </IonCard>
            <IonButton expand="full" fill="solid" onClick={() => setShowDetailModal(false)}>
              Close
            </IonButton>
          </IonContent>
        </IonModal>
      </IonContent>
    </IonPage>
  );
};

export default MovieList;
