import React from 'react';
import { IonPage, IonContent } from '@ionic/react';
import './Home.css';

const Home: React.FC = () => (
  <IonPage>
    <IonContent fullscreen className="home">

      {/* HERO FULL SCREEN */}
      <section className="hero-fullscreen">
        <div className="hero-inner">
          <h1 className="brand">a25</h1>
          <p className="tagline">movie<br />frames</p>
        </div>
      </section>

      {/* TRENDING SECTION */}
      <section className="trending-section">
        <h2 className="section-title">TRENDING</h2>
        <div className="poster-row">
          <div className="poster">
            <img src="https://image.tmdb.org/t/p/w600_and_h900_bestv2/8LJJjLjAzAwXS40S5mx79PJ2jSs.jpg" alt="Dune: Part Two" />
          </div>
          <div className="poster">
            <img src="https://image.tmdb.org/t/p/w600_and_h900_bestv2/1OsQJEoSXBjduuCvDOlRhoEUaHu.jpg" alt="Oppenheimer" />
          </div>
          <div className="poster">
            <img src="https://image.tmdb.org/t/p/w600_and_h900_bestv2/qZUmMxJbGmkIYwnS7qRfSOREmvC.jpg" alt="Top Gun: Maverick" />
          </div>
          <div className="poster">
            <img src="https://image.tmdb.org/t/p/w600_and_h900_bestv2/49pANIZXRAdHUiWjjBv4vxPeqRC.jpg" alt="Babylon" />
          </div>
        </div>
      </section>

      {/* WEEKLY SUGGESTIONS */}
      <section className="weekly-section">
        <h2 className="section-title">WEEKLY SUGGESTIONS</h2>
        <div className="poster-row">
          <div className="poster">
            <img src="https://image.tmdb.org/t/p/w600_and_h900_bestv2/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg" alt="Interstellar" />
          </div>
          <div className="poster">
            <img src="https://image.tmdb.org/t/p/w600_and_h900_bestv2/edv5CZvWj09upOsy2Y6IwDhK8bt.jpg" alt="Inception" />
          </div>
          <div className="poster">
            <img src="https://image.tmdb.org/t/p/w600_and_h900_bestv2/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg" alt="Parasite" />
          </div>
          <div className="poster">
            <img src="https://image.tmdb.org/t/p/w600_and_h900_bestv2/qJ2tW6WMUDux911r6m7haRef0WH.jpg" alt="The Dark Knight" />
          </div>
        </div>
      </section>

      {/* ABOUT US SECTION */}
      <section className="about-section">
        <h2 className="about-title">About Us</h2>
        <p className="about-text">
          a25 is a minimal editorial movie showcase. Our goal is to highlight visual storytelling,
          curating film selections and weekly highlights with a focus on design, cinematography,
          and narrative depth.
        </p>
      </section>

      {/* FOOTER */}
      <footer className="footer">
        <p>© 2025 a25 — All rights reserved.</p>
      </footer>

    </IonContent>
  </IonPage>
);

export default Home;